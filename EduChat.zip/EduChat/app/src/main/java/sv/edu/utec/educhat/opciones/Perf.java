package sv.edu.utec.educhat.opciones;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import sv.edu.utec.educhat.R;

public class Perf extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.perfil);
    }

}
